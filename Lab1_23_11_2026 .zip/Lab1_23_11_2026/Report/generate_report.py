"""Generates Lab-01-Report.pdf (same section format as the lab template).
Run:  pip install reportlab   then   python generate_report.py
"""
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import cm
from reportlab.lib.utils import ImageReader
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Image,
                                ListFlowable, ListItem, KeepTogether)

H = ParagraphStyle("H", fontName="Times-Bold", fontSize=14, leading=18, spaceBefore=12, spaceAfter=3)
SH = ParagraphStyle("SH", fontName="Times-Bold", fontSize=11.5, leading=15, spaceBefore=4, spaceAfter=6)
B = ParagraphStyle("B", fontName="Times-Roman", fontSize=11.5, leading=15, spaceAfter=3)


def bullets(items):
    return ListFlowable([ListItem(Paragraph(i, B), leftIndent=18) for i in items],
                        bulletType="bullet", start="•", leftIndent=18)


def img(path, width_cm=5.2):
    w, h = ImageReader(path).getSize()
    return Image(path, width=width_cm * cm, height=width_cm * cm * h / w, hAlign="LEFT")


story = [
    Paragraph("1. Experiment No. 01", H),
    Paragraph("2. Experiment Title", H),
    Paragraph("Introduction to Web Programming using HTML, CSS and JavaScript.", B),

    Paragraph("3. Objectives", H),
    Paragraph("The main objectives of this experiment are:", B),
    bullets([
        "To understand the basic concepts of web programming.",
        "To learn the structure of an HTML document and its input elements.",
        "To understand how an external CSS file is used to style a web page.",
        "To learn how JavaScript reads user input and shows a result.",
        "To create a simple greeting web page using HTML, CSS and JavaScript.",
    ]),

    Paragraph("4. Theory", H),
    Paragraph("Web programming is the process of creating websites and web applications. "
              "Three core technologies work together to build interactive web pages.", B),
    Paragraph("<b>HTML (HyperText Markup Language):</b> HTML creates the structure and content of a "
              "page. It defines headings, paragraphs, text input boxes and buttons.", B),
    Paragraph("<b>CSS (Cascading Style Sheets):</b> CSS controls the appearance of a page, such as "
              "colors, fonts, borders, spacing and layout.", B),
    Paragraph("<b>JavaScript:</b> JavaScript is a programming language that makes a page "
              "interactive. It can read the value typed in an input box, check it with an "
              "if-else condition and display a message when a button is clicked.", B),

    Paragraph("5. Required Software", H),
    bullets([
        "Operating System: Windows",
        "Web Browser: Google Chrome",
        "Code Editor: Visual Studio Code / GitHub Web Editor",
        "Technologies: HTML5, CSS3 and JavaScript (ES6)",
    ]),

    Paragraph("6. Source Code", H),
    Paragraph("The complete source code is available in the project repository on GitHub.", B),
    bullets([
        "<b>index.html</b> - page structure: headings, name input box, button, output line.",
        "<b>style.css</b> - box design, colors, input and button style, success style.",
        "<b>script.js</b> - reads the name, checks if empty, shows the greeting message.",
    ]),

    KeepTogether([
        Paragraph("7. Output", H),
        Paragraph("Output 1: Before Button Click", SH),
        img("../Output/Output_before_Click.png"),
    ]),
    Spacer(1, 10),
    Paragraph("Output 2: After Button Click", SH),
    Paragraph("(The name was typed in the input box and the Greet Me! button was clicked.)", B),
    img("../Output/Output_after_Click.png"),

    KeepTogether([
        Paragraph("8. Discussion", H),
        Paragraph("In this experiment, a simple greeting web page was developed using HTML, CSS "
                  "and JavaScript. HTML was used to create the page structure, CSS was used to "
                  "improve its appearance, and JavaScript was used to add interactive functionality.", B),
        Paragraph("When the user typed a name and clicked the \"Greet Me!\" button, JavaScript read "
                  "the name, displayed a greeting message and changed the box color to green. If the "
                  "input was empty, a warning message was shown instead.", B),
        Paragraph("The experiment helped to understand how these three technologies work together "
                  "in web development.", B),
    ]),

    KeepTogether([
        Paragraph("9. Conclusion", H),
        Paragraph("Through this experiment, the basic concepts of web programming were learned. "
                  "A simple interactive web page was successfully created using HTML, CSS and "
                  "JavaScript.", B),
        Paragraph("This experiment provided a foundation for learning more advanced web development "
                  "concepts in future laboratory sessions.", B),
    ]),
]

doc = SimpleDocTemplate("Lab-01-Report.pdf", pagesize=A4, leftMargin=3*cm, rightMargin=3*cm,
                        topMargin=2.5*cm, bottomMargin=2.5*cm,
                        title="Lab 01 Report - Web Programming", author="Raju Mitra")
doc.build(story)
print("Created Lab-01-Report.pdf")
