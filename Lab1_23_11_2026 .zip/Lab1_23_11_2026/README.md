# Lab 01 - Introduction to Web Programming using HTML, CSS and JavaScript

A simple greeting page: type your name, click the button and get a welcome message.

## Features
- Text input box for the name
- "Greet Me!" button shows a greeting message
- Shows a warning if the name box is empty
- Box turns green after a successful greeting

## Project Structure
```
Lab1_23_11_2026/
├── Code/
│   ├── index.html        # page structure
│   ├── style.css         # styling
│   └── script.js         # click event and logic
├── Output/
│   ├── Output_before_Click.png
│   └── Output_after_Click.png
├── Report/
│   ├── Lab-01-Report.pdf # final lab report
│   └── generate_report.py # (optional) script that builds the PDF
└── README.md
```

## How to Run
1. Download or clone this repository.
2. Open `Code/index.html` in Google Chrome.

## Regenerate the PDF Report (optional)
```bash
pip install reportlab
cd Report
python generate_report.py
```

## Technologies
HTML5, CSS3, JavaScript (ES6)
